# XCrack
A cli tool for offline password attacks

## Features
- Brute force hash cracking
- Wordlist hash cracking
- Multiple Core usage for Brute force and Wordlists
- Wordlist generation
- Wordlist merging
- Wordlist clearning
- Hash generation

## Contributing
### Bug fixes:
For quick bug fixes open an issue or pull request with the description of the error and/or a fix of the error.

### Supporting the project
If you want to contribute to the project in the long run, you can write me an email to adzsx@proton.me or submit one through my [Website](https://adzsx.github.io/#contact)


## [Documentation](https://adzsx.github.io/projects/xcrack/)


### [GPL License](https://choosealicense.com/licenses/gpl-3.0/)
